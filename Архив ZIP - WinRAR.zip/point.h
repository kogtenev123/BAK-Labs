#ifndef POINT_H
#define POINT_H

#include "springs.h"
#include "spring.h"
#include "vector.h"
#include "vector"
using namespace std;

class Point{
public:
    Point();

    Point(double p, double v, double u, double V1, double V2);

    double Weight();

    void hook(Spring& spring);

    void del_hook();

    //double loc_x();

    double loc_y();

    //void move(Vector dr);

    Vector Movement(double dt);

private:
    vector<Spring*> s;
    Vector r;
    double m;
    Vector V;
    Vector Force(double g);
};

#endif // POINT_H
