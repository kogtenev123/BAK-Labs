#include "spring.h"
#include "springs.h"
#include "vector.h"
#include "point.h"

Point :: Point() {
    m = 0;
}

Point :: Point(double p, double v, double u, double V1, double V2) {
    m = p;
    Vector t(v, u);
    Vector q(V1, V2);
    r = t;
    V = q;
}

double Point :: Weight() {
    return m;
}

void Point :: hook(Spring& spring) {
    if (spring.load(m, r)) {
        Spring *spr = &spring;
        s.push_back(spr);
    }
}

void Point :: del_hook() {
    s.pop_back();
}

double Point :: loc_y() {
    return r.y;
}

/*void Point :: move(Vector dr) {
    r = r + dr;
    for(auto &y : s) {
        y.Move(dr);
    }
}*/

Vector Point :: Movement(double dt) {
    double g = -9.8;
    Vector a = Force(g);
    a = a / m;
    Vector V1 = V;
    V = V + dt * a;
    return dt * V1 + (dt * dt / 2) * a;
}

Vector Point :: Force(double g) {
    Vector f(g * m);
    for(auto &y : s) {
        Vector u = y->force();
        f = f + u;
    }
    return f;
}





